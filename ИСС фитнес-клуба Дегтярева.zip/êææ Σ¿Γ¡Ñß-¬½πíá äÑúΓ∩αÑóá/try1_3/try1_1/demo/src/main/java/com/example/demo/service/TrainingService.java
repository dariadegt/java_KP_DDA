package com.example.demo.service;

import com.example.demo.domain.Client;
import com.example.demo.domain.Training;
import com.example.demo.repository.TrainingRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
public class TrainingService {

    private final TrainingRepository trainingRepository;

    public List<Training> getAllTrainings() {
        return trainingRepository.findAll();
    }

    /*public List<Training> getTrainingsByTrainer(String trainerName) {
        return trainingRepository.findByTrainerFullName(trainerName);
    }*/

    /**
     * Метод добавления тренировки в базу
     * @param training - объект типа Training, с которого вставляется информация
     */
    public void addTraining(Training training) {
        // Сохраняем тренировку в базе данных
        trainingRepository.save(training);
    }

    /**
     * Метод получения списка всех тренировок имеющихся в базе по названию
     * @param name - название искомой тренировки
     * @return - тренировка с соответствующим названием
     */
    public List<Training> getTrainingsByName(String name) {
        return trainingRepository.findByName(name);
    }

    public Optional<Training> getTrainingById(Long trainingid) {
        return trainingRepository.findById(trainingid);
    }


    public void updateTraining(Long trainingid, Training updatedTraining) {
        Optional<Training> existingTraining = trainingRepository.findById(trainingid);
        if (existingTraining.isPresent()) {
            Training training = existingTraining.get();
            training.setName(updatedTraining.getName());
            training.setStartTime(updatedTraining.getStartTime());
            training.setEndTime(updatedTraining.getEndTime());
            training.setCost_of_1_training(updatedTraining.getCost_of_1_training());
            trainingRepository.save(training);
        }
    }

    public void deleteTraining(Long trainingid) { trainingRepository.deleteById(trainingid);
    }

    public List<Training> getTrainingsByFilter(String trainingName,  Integer cost_of_1_training) {
        // Получаем все тренировки
        List<Training> trainings = trainingRepository.findAll();

        if (trainingName != null && !trainingName.isEmpty()) {
            trainings = trainings.stream()
                    .filter(training -> training.getName().toLowerCase().contains(trainingName.toLowerCase()))
                    .collect(Collectors.toList());
        }

        if (cost_of_1_training != null) {
            trainings = trainings.stream()
                    .filter(training -> training.getCost_of_1_training().equals(cost_of_1_training))
                    .collect(Collectors.toList());
        }

        return trainings;
    }



/*    public Map<String, TrainingStatistics> getStatistics() {
        List<Training> trainings = trainingRepository.findAll();

        return trainings.stream()
                .collect(Collectors.groupingBy(Training::getName,
                        Collectors.collectingAndThen(
                                Collectors.toList(),
                                this::calculateStatistics)));
    }

    private TrainingStatistics calculateStatistics(List<Training> trainings) {
        double averageCost = traВinings.stream().mapToDouble(Training::getCost_of_1_training).average().orElse(0);
        double averageDuration = trainings.stream().mapToDouble(training ->
                Duration.between(training.getStartTime(), training.getEndTime()).toMinutes()).average().orElse(0);

        Training maxCostTraining = trainings.stream().max((t1, t2) ->
                Double.compare(t1.getCost_of_1_training(), t2.getCost_of_1_training())).orElse(null);
        Training minCostTraining = trainings.stream().min((t1, t2) ->
                Double.compare(t1.getCost_of_1_training(), t2.getCost_of_1_training())).orElse(null);

        return new TrainingStatistics(
                averageCost,
                averageDuration,
                maxCostTraining != null ? maxCostTraining.getCost_of_1_training() : 0,
                maxCostTraining != null ? maxCostTraining.getStartTime().toString() : "",
                minCostTraining != null ? minCostTraining.getCost_of_1_training() : 0,
                minCostTraining != null ? minCostTraining.getStartTime().toString() : ""
        );
    }*/

/*    public Map<String, TrainingStatistics> getStatistics() {
        List<Training> trainings = trainingRepository.findAll();

        return trainings.stream()
                .collect(Collectors.groupingBy(Training::getName,
                        Collectors.collectingAndThen(
                                Collectors.toList(),
                                this::calculateStatistics)));
    }

    private TrainingStatistics calculateStatistics(List<Training> trainings) {
        double averageCost = trainings.stream().mapToDouble(Training::getCost_of_1_training).average().orElse(0);
        double averageDuration = trainings.stream().mapToInt(training -> {
            // Предполагается, что у вас есть метод для получения продолжительности
            return (int) Duration.between(training.getStartTime(), training.getEndTime()).toMinutes();
        }).average().orElse(0);

        Training maxCostTraining = trainings.stream().max((t1, t2) -> Double.compare(t1.getCost_of_1_training(), t2.getCost_of_1_training())).orElse(null);
        Training minCostTraining = trainings.stream().min((t1, t2) -> Double.compare(t1.getCost_of_1_training(), t2.getCost_of_1_training())).orElse(null);

        return new TrainingStatistics(averageCost, averageDuration, maxCostTraining, minCostTraining);
    }*/
}
