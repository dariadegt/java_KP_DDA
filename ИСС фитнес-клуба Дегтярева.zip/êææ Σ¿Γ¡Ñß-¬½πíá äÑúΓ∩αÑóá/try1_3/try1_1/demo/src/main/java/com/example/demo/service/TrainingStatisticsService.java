package com.example.demo.service;

import com.example.demo.domain.Training;
import com.example.demo.repository.TrainingRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class TrainingStatisticsService {

    private final TrainingRepository trainingRepository;

    public TrainingStatisticsService(TrainingRepository trainingRepository) {
        this.trainingRepository = trainingRepository;
    }

    // Метод для расчета статистики
    public TrainingStats calculateStatistics() {
        // Получаем среднюю стоимость и продолжительность тренировок
        double averageCost = trainingRepository.findAverageCost();
        double averageDuration = trainingRepository.findAverageDuration();

        // Получаем тренировки с максимальной и минимальной стоимостью
        Training maxCostTraining = trainingRepository.findTrainingWithMaxCost();
        Training minCostTraining = trainingRepository.findTrainingWithMinCost();

        // Возвращаем объект TrainingStats с расчетами
        return new TrainingStats(averageCost, averageDuration, maxCostTraining, minCostTraining);
    }
}
