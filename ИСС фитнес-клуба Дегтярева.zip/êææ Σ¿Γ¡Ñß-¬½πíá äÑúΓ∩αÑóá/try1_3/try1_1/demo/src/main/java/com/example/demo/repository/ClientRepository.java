package com.example.demo.repository;
import com.example.demo.domain.Client;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;


/**
 * Репозиторий для связи с базой клиентов
 */
public interface ClientRepository extends JpaRepository<Client, Long> {
    Optional<Client> findByFullName(String fullName);  // Используем поле fullName
    Optional<Client> findByLogin(String login);
}
