package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder passwordEncoder) {
        // Создаем пользователя клиента
        UserDetails lewisHamilton = User.builder()
                .username("lewis_hamilton")
                .password(passwordEncoder.encode("f123"))
                .roles("CLIENT")
                .build();

        UserDetails maxVerstappen = User.builder()
                .username("max_verstappen")
                .password(passwordEncoder.encode("f145"))
                .roles("CLIENT")
                .build();


        UserDetails monkeyDLuffy = User.builder()
                .username("monkey_d_luffy")
                .password(passwordEncoder.encode("anime102"))
                .roles("CLIENT")
                .build();

        UserDetails narutoUzumaki = User.builder()
                .username("naruto_uzumaki")
                .password(passwordEncoder.encode("anime101"))
                .roles("CLIENT")
                .build();

// Тренеры (Персонажи аниме)
        UserDetails kakashiHatake = User.builder()
                .username("kakashi")
                .password(passwordEncoder.encode("trainerpass1"))
                .roles("TRAINER")
                .build();

        UserDetails killerBee = User.builder()
                .username("killerbee")
                .password(passwordEncoder.encode("trainerpass2"))
                .roles("TRAINER")
                .build();




        // Возвращаем пользователей в память
        return new InMemoryUserDetailsManager(
                lewisHamilton, maxVerstappen, monkeyDLuffy, narutoUzumaki,
                kakashiHatake, killerBee
        );
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/login", "/css/**", "/js/**").permitAll()
                        .requestMatchers("/trainers/dashboard").hasRole("TRAINER")
                        .requestMatchers("/clients/dashboard").hasRole("CLIENT")
                        .requestMatchers("/schedule").authenticated()
                        .requestMatchers("/about-author").authenticated()

                        .anyRequest().authenticated()
                )
                .formLogin(login -> login
                        .successHandler((request, response, authentication) -> {
                            var authorities = authentication.getAuthorities();
                            if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_CLIENT"))) {
                                response.sendRedirect("/clients/dashboard");
                            } else if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_TRAINER"))) {
                                response.sendRedirect("/trainers/dashboard");
                            } else {
                                response.sendRedirect("/");  // Резервный случай
                            }
                        })
                        .permitAll())


                .logout(logout -> logout
                        .logoutSuccessUrl("/"));

        return http.build();
    }
}
