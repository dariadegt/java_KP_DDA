package com.example.demo.controller;

import com.example.demo.domain.Training;
/*import com.example.demo.service.TrainingStatistics;*/
import com.example.demo.service.TrainingStatisticsService;
import com.example.demo.service.TrainingStats;
import lombok.AllArgsConstructor;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.example.demo.domain.Client;
import com.example.demo.service.ClientService;
import com.example.demo.service.TrainingService;

import java.util.Map;

@AllArgsConstructor
@Controller
@RequestMapping("/clients")
public class ClientController {

    private final TrainingService trainingService;
    private final ClientService clientService;
    private final TrainingStatisticsService statisticsService;

    /**
     * Контроллер для работы с клиентами.
     * Обрабатывает запросы, связанные с расписанием тренировок и информации
     /**
     * Контроллер для отображения панели клиента.
     * @param model - носитель типа Model, для вставки в темплейт
     * @return - имя шаблона, отображающего панель клиента
     */
    @GetMapping("/dashboard")
    public String getClientDashboard(Model model) {
        // Получаем статистику через сервис
        TrainingStats statistics = statisticsService.calculateStatistics();

        // Добавляем объект статистики в модель
        model.addAttribute("statistics", statistics);

        // Отправляем данные в представление
        return "client-dashboard";  // Шаблон для клиента
    }
    /**
     * Контроллер для отображения расписания тренировок.
     * @param trainingName - название тренировки для фильтрации расписания (может быть null)
     * @param model - носитель типа Model, для вставки в темплейт
     * @return - имя шаблона, отображающего расписание тренировок
     */
    @GetMapping("/schedule")
    public String viewSchedule(@RequestParam(required = false) String trainingName, Model model) {
        if (trainingName != null) {
            // Передаем название тренировки, чтобы получить соответствующие тренировки
            model.addAttribute("trainings", trainingService.getTrainingsByName(trainingName));
        } else {
            model.addAttribute("trainings", trainingService.getAllTrainings());
        }
        return "schedule"; // Шаблон для отображения расписания
    }

/*    @GetMapping("/dashboard")
    public String clientDashboard(Model model) {
        Map<String, TrainingStatistics> statistics = trainingService.getStatistics();
        model.addAttribute("statistics", statistics);

        return "client-dashboard"; // Отображаем шаблон client-dashboard.html
    }*/


}
