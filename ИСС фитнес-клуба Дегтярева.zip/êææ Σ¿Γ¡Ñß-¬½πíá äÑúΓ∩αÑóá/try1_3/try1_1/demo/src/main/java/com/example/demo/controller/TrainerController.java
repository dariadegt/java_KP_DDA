package com.example.demo.controller;

import com.example.demo.domain.Training;
import com.example.demo.service.TrainingStatisticsService;
import com.example.demo.repository.ClientRepository;
import com.example.demo.service.*;
import lombok.AllArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.ui.Model;
import com.example.demo.domain.Client;
import com.example.demo.domain.Trainer;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Controller
@RequestMapping("/trainers")
public class TrainerController {

    private final TrainingService trainingService;
    private final ClientService clientService;


    /**
     * Контроллер для вывода панели тренера
     * @param model - объект типа Model с данными выводимыми на странице
     * @return - выводимая панель тренера
     */
    @GetMapping("/dashboard")
    public String trainerDashboard(Model model) {
        List<Client> clients = clientService.getAllClients(); // Получаем всех клиентов
        model.addAttribute("clients", clients); // Передаем в модель
        return "trainer-dashboard"; // Отображаем шаблон trainer-dashboard.html
    }


    /**
     * Форма для добавления новой тренировки
     * @param model - объект типа Model с данными выводимыми на странице
     * @return - Страница с шаблоном для добавления тренировки
     */
    @GetMapping("/add-training")
    public String showAddTrainingForm(Model model) {
        model.addAttribute("training", new Training()); // Пустая форма для новой тренировки
        return "add-training";  // Шаблон для добавления тренировки
    }


    /**
     * Контроллер для добавления новой тренировки
     * @param training - объект типа Training с добавляемыми данными
     * @return - Перенаправление на страницу тренера
     */
    @PostMapping("/add-training")
    public String addTraining(@ModelAttribute("training") Training training) {
        trainingService.addTraining(training);  // Добавляем тренировку с помощью сервиса
        return "redirect:/trainers/dashboard"; // После добавления перенаправляем на страницу тренера
    }


    /**
     * Контроллер для просмотра всех тренировок.
     *
     * @param model - модель, в которую будут добавлены данные о тренировках
     * @return - Шаблон для отображения списка тренировок
     */
    @GetMapping("/trainings")
    public String viewAllTrainings(Model model) {
        List<Training> trainings = trainingService.getAllTrainings(); // Получаем все тренировки
        model.addAttribute("trainings", trainings); // Передаем в модель
        return "schedule"; // Шаблон для отображения списка тренировок
    }


    /**
     * Отображение формы для добавления нового клиента.
     *
     * @param model - модель, в которую будет добавлен новый объект клиента
     * @return - Шаблона для добавления клиента
     */
    @GetMapping("/add-client")
    public String showAddClientForm(Model model) {
        model.addAttribute("client", new Client()); // Пустая форма для нового клиента
        return "add-client";  // Шаблон для добавления клиента
    }
    /**
     * Контроллер для добавления нового клиента.
     *
     * @param client - объект типа Client, который будет добавлен
     * @return - Перенаправление на страницу списка клиентов
     */
    @PostMapping("/add-client")
    public String addClient(@ModelAttribute("client") Client client) {
        clientService.addClient(client);  // Сохраняем клиента в базе
        return "redirect:/trainers/clients";  // Перенаправляем на страницу списка клиентов
    }


    /**
     * Контроллер для удаления клиента по его id.
     *
     * @param clientId - id клиента, который будет удален
     * @return - Перенаправление на страницу списка клиентов
     */
    @GetMapping("/delete-client/{clientId}")
    public String deleteClient(@PathVariable Long clientId) {
        clientService.deleteClient(clientId);  // Удаляем клиента через сервис
        return "redirect:/trainers/clients";  // Перенаправляем на страницу списка клиентов
    }


    /**
     * Контроллер для отображения формы обновления данных клиента.
     *
     * @param clientId - id клиента, данные которого будут обновлены
     * @param model - модель, в которую будут добавлены данные клиента
     * @return - шаблон для редактирования клиента или перенаправление на страницу списка клиентов
     */
    @GetMapping("/edit-client/{clientId}")
    public String showEditClientForm(@PathVariable Long clientId, Model model) {
        Optional<Client> client = clientService.getClientById(clientId);  // Получаем клиента по ID
        if (client.isPresent()) {
            model.addAttribute("client", client.get());  // Передаем данные клиента в модель
            return "edit-client";  // Шаблон для редактирования клиента
        } else {
            // Если клиента не существует, перенаправляем на страницу списка клиентов
            return "redirect:/trainers/clients";
        }
    }


    /**
     * Контроллер обновления клиента по id
     *
     * @param clientId - id клиента, данные которого будут обновлены
     * @param updatedClient объект с обновленными данными клиента
     * @return - Перенаправление на страницу списка клиентов
     */
    @PostMapping("/edit-client/{clientId}")
    public String updateClient(@PathVariable Long clientId, @ModelAttribute("client") Client updatedClient) {
        clientService.updateClient(clientId, updatedClient);  // Обновляем данные клиента через сервис
        return "redirect:/trainers/clients";  // Перенаправляем на страницу списка клиентов
    }


    /**
     * Метод для отображения списка всех клиентов.
     *
     * @param model  - модель, в которую будут добавлены данные о клиентах
     * @return - Шаблон для отображения списка клиентов
     */
    @GetMapping("/clients")
    public String viewClients(Model model) {
        List<Client> clients = clientService.getAllClients();  // Получаем всех клиентов
        model.addAttribute("clients", clients);  // Передаем список клиентов в модель
        return "clients";  // Шаблон для отображения списка клиентов
    }

    /**
     * Контроллер для отображения формы обновления данных клиента.
     *
     * @param trainingId - id клиента, данные которого будут обновлены
     * @param model - модель, в которую будут добавлены данные клиента
     * @return - шаблон для редактирования клиента или перенаправление на страницу списка клиентов
     */
    @GetMapping("/edit-training/{trainingId}")
    public String showEditTrainingForm(@PathVariable Long trainingId, Model model) {
        Optional<Training> training = trainingService.getTrainingById(trainingId);
        if (training.isPresent()) {
            model.addAttribute("training",training.get());
            return "edit-training";  // Шаблон для редактирования клиента
        } else {
            return "redirect:/schedule";
        }
    }


    /**
     * Контроллер обновления клиента по id
     *
     * @param trainingId - id клиента, данные которого будут обновлены
     * @param updatedTraining объект с обновленными данными клиента
     * @return - Перенаправление на страницу списка клиентов
     */
    @PostMapping("/edit-training/{trainingId}")
    public String updateTraining(@PathVariable Long trainingId, @ModelAttribute("training") Training updatedTraining) {
        trainingService.updateTraining(trainingId, updatedTraining);  // Обновляем данные клиента через сервис
        return "redirect:/schedule";  // Перенаправляем на страницу списка клиентов
    }

    @GetMapping("/delete-training/{trainingId}")
    public String deleteTraining(@PathVariable Long trainingId) {
        trainingService.deleteTraining(trainingId);  // Удаляем клиента через сервис
        return "redirect:/schedule";  // Перенаправляем на страницу списка клиентов
    }








}