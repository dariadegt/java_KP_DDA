package com.example.demo.domain;

import jakarta.persistence.*;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.List;

/**
 * Суперкласс, от которого наследуются объект клиента и тренера
 */
@Data
@MappedSuperclass
public abstract class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String fullName;

    @Column(nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate birthdate;

    @Column(nullable = false)
    private String phoneNumber;

    @Column(nullable = true, unique = true)
    private String login;

    @Column(nullable = true)
    private String password;


}
