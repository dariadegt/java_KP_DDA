package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AboutAuthorController {

    /**
     * Контроллер для отображения страницы "Об авторе"
     * @return - имя HTML-шаблона, который будет отображен
     */
    @GetMapping("/about-author")
    public String aboutAuthor() {
        return "about-author";  // Имя HTML-шаблона для страницы "Об авторе"
    }
}
