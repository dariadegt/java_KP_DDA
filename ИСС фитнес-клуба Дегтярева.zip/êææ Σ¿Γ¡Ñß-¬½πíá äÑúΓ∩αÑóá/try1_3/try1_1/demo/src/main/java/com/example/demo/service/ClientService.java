package com.example.demo.service;

import com.example.demo.domain.Client;
import com.example.demo.repository.ClientRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Service
public class ClientService {

    private final ClientRepository clientRepository;



    /**
     * Метод добавление в базу нового клиента
     * @param client - объект типа Client, с которого вставляется информация
     * @return добавленный клиент
     */
    public Client addClient(Client client) {
        return clientRepository.save(client);
    }


    /**
     * Метод обновление существующего клиента имеющегося в базе
     * @param clientId - id клиента, у которого надо обновить данные
     * @param updatedClient - объект типа Client, с которого вставляется информация
     * @return клиент с обновлёнными данными
     */
    public Client updateClient(Long clientId, Client updatedClient) {
        Optional<Client> existingClient = clientRepository.findById(clientId);
        if (existingClient.isPresent()) {
            Client client = existingClient.get();
            client.setFullName(updatedClient.getFullName());
            client.setBirthdate(updatedClient.getBirthdate());
            client.setPhoneNumber(updatedClient.getPhoneNumber());
            client.setLogin(updatedClient.getLogin());
            client.setPassword(updatedClient.getPassword());
            return clientRepository.save(client);
        } else {
            throw new IllegalArgumentException("Client not found with id: " + clientId);
        }
    }



    /**
     * Метод удаления клиента имеющегося в базе
     * @param clientId - id клиента, которого надо удалить
     */
    public void deleteClient(Long clientId) {
        clientRepository.deleteById(clientId);
    }



    /**
     * Метод поиска клиента по имени имеющегося в базе
     * @param fullName - имя клиента, которого надо найти
     * @return - клиент с соответствующим именем
     */
    public Optional<Client> findByFullName(String fullName) {
        return clientRepository.findByFullName(fullName);
    }



    /**
     * Метод получения списка всех имеющихся в базе клиентов
     * @return - список имеющихся в базе клиентов
     */
    public List<Client> getAllClients() {
        return clientRepository.findAll();
    }


    /**
     * Метод поиска имеющегося в базе клиента по id
     * @param clientId - id клиента, которого надо найти
     * @return - клиент с соответствующим id
     */
    public Optional<Client> getClientById(Long clientId) {
        return clientRepository.findById(clientId);
    }
}
