package com.example.demo.controller;

import com.example.demo.domain.Training;
import com.example.demo.service.TrainingService;
import lombok.AllArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/schedule")
@AllArgsConstructor
public class ScheduleController {

    private final TrainingService trainingService;

    /**
     * Обрабатывает запрос на просмотр расписания тренировок.
     * @param trainingName - название тренировки для фильтрации (опционально)
     * @param model - носитель данных типа Model, для передачи информации в представление
     * @return - имя шаблона, отображающего расписание тренировок
     */
    @GetMapping
    public String viewSchedule(@RequestParam(required = false) String trainingName,
                               @RequestParam(required = false) Integer cost_of_1_training,
                               Model model,
                               Authentication authentication) {
        // Проверка роли пользователя на тренера
        boolean isTrainer = authentication.getAuthorities().stream()
                .anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals("ROLE_TRAINER"));

        // Проверка роли пользователя на клиента
        boolean isClient = authentication.getAuthorities().stream()
                .anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals("ROLE_CLIENT"));

        // Добавляем флаги в модель
        model.addAttribute("isTrainer", isTrainer);
        model.addAttribute("isClient", isClient);

        // Получаем список тренировок с применением фильтра
        List<Training> trainings = trainingService.getTrainingsByFilter(trainingName, cost_of_1_training);

        // Добавляем данные в модель
        model.addAttribute("trainings", trainings);

        return "schedule"; // Шаблон для расписания
    }


}
