package com.example.demo.repository;


import com.example.demo.domain.Trainer;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Репозиторий для связи с базой тренеров
 */
public interface TrainerRepository extends JpaRepository<Trainer, Long> {

}

