package com.example.demo.domain;

import jakarta.persistence.*;
import lombok.Data;


/**
 * Сущность Тренер
 * id - идентификатор, уникальный, обязательный к заполнению, присваевается автоматически
 * name - имя тренера
 * specialization - специализация
 */
@Data
@Entity
@Table(name = "trainers")
public class Trainer extends User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String specialization; // Например, "Йога", "Кроссфит"

}
