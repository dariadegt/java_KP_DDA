package com.example.demo.service;

import com.example.demo.domain.Training;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class
TrainingStats {

    private double averageCost;
    private double averageDuration; // в минутах
    private double maxCost;
    private String maxCostDate; // дата, когда была максимальная стоимость
    private double minCost;
    private String minCostDate; // дата, когда была минимальная стоимость

    // Конструктор, который принимает значения для всех полей
    public TrainingStats(double averageCost, double averageDuration, Training maxCostTraining, Training minCostTraining) {
        this.averageCost = averageCost;
        this.averageDuration = averageDuration;
        this.maxCost = maxCostTraining != null ? maxCostTraining.getCost_of_1_training() : 0;
        this.maxCostDate = maxCostTraining != null ? maxCostTraining.getStartTime().toString() : "";
        this.minCost = minCostTraining != null ? minCostTraining.getCost_of_1_training() : 0;
        this.minCostDate = minCostTraining != null ? minCostTraining.getStartTime().toString() : "";
    }

    // Конструктор для использования с raw данными (числовыми значениями и датами)
    public TrainingStats(Double avgCost, Double avgDuration, Double maxCost, LocalDateTime maxCostDate, Double minCost, LocalDateTime minCostDate) {
        this.averageCost = avgCost != null ? avgCost : 0;
        this.averageDuration = avgDuration != null ? avgDuration : 0;
        this.maxCost = maxCost != null ? maxCost : 0;
        this.maxCostDate = maxCostDate != null ? maxCostDate.toString() : "";
        this.minCost = minCost != null ? minCost : 0;
        this.minCostDate = minCostDate != null ? minCostDate.toString() : "";
    }
}
