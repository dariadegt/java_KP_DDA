package com.example.demo.service;

import com.example.demo.domain.Trainer;
import com.example.demo.domain.Client;
import com.example.demo.domain.Training;
import com.example.demo.repository.TrainerRepository;
import com.example.demo.repository.ClientRepository;
import com.example.demo.repository.TrainingRepository;
import lombok.AllArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Service
public class TrainerService {

    private final TrainerRepository trainerRepository;
    private final ClientRepository clientRepository;
    private final TrainingRepository trainingRepository;


    /**
     * Метод поиска имеющегося в базе клиента по id
     *
     * @param id - id искомого клиента
     * @return - клиент с соответствующим id
     */
    public Client getClientById(Long id) {
        Optional<Client> clientOptional = clientRepository.findById(id);
        return clientOptional.orElseThrow(() -> new IllegalArgumentException("Client not found with id: " + id));
    }
}


