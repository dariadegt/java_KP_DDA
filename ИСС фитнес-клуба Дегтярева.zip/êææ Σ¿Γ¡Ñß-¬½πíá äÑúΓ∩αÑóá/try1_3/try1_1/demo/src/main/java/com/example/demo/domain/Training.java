package com.example.demo.domain;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;


/** Сущность
 * id - идентификатор, уникальный, обязательный к заполнению, присваевается автоматически
 * name - название тренировки
 * startTime - время начала
 * endTime - время окончания
 * coach - тренер ведущий данную тренировку
 */
    @Data
    @Entity
    @Table(name = "trainings")
    public class Training {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @Column(nullable = false)
        private String name; // Название тренировки

        @Column(nullable = false)
        private LocalDateTime startTime;

        @Column(nullable = false)
        private LocalDateTime endTime;

        @Column(nullable = false)
        private Integer cost_of_1_training;

        /*@Column(nullable = false)
        private String coach;*/

    }
