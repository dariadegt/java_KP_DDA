package com.example.demo.controller;

import com.example.demo.domain.Training;
import com.example.demo.service.TrainingService;
import lombok.AllArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Controller
@RequestMapping("/trainings")
public class TrainingController {

    private final TrainingService trainingService;


    // Страница подробной информации о тренировке

    /**
     * Контроллер для вывода подробной информации о тренировке
     * @param id - id тренировки, информация о которой требуется
     * @param model - носитель типа Model, для вставки в темплейт
     * @return - страница с подробной информацией о тренировке
     */
    @GetMapping("/trainings")
    public String viewTrainingDetails(@PathVariable Long id, Model model) {
        Training training = trainingService.getAllTrainings()
                .stream()
                .filter(t -> t.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Training not found with id: " + id));

        model.addAttribute("training", training);
        return "training-details"; // Возвращает шаблон training-details.html
    }
    @GetMapping("/edit-training/{id}")
    public String editTraining(@PathVariable("id") Long id, Model model) {
        // Получаем тренировку по ID
        Optional<Training> optionalTraining = trainingService.getTrainingById(id);

        if (optionalTraining.isEmpty()) {
            // Обработка случая, когда тренировка не найдена
            return "redirect:/error"; // или другая логика
        }

        // Извлекаем объект Training
        Training training = optionalTraining.get();

        // Форматируем дату
        String formattedStartTime = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm").format(training.getStartTime());

        // Добавляем атрибуты в модель
        model.addAttribute("training", training);
        model.addAttribute("formattedStartTime", formattedStartTime);

        // Возвращаем имя шаблона для редактирования
        return "edit-training";
    }




}
