package com.example.demo.domain;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.type.descriptor.java.YearJavaType;

import java.security.cert.CertificateFactory;


/**
 * Сущность Клиент
 * id - идентификатор, уникальный, обязательный к заполнению, присваевается автоматически
 * coach - тренер, ведущий тренировку
 */
@Data
@Entity
@Table(name = "clients")
public class Client extends User{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = true)
    private String coach;

}
