package com.example.demo.repository;

import com.example.demo.domain.Training;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;


/**
 * Репозиторий для связи с базой тренировок
 */
public interface TrainingRepository extends JpaRepository<Training, Long> {
    List<Training> findByName(String name);
        // Средняя стоимость тренировки
        @Query("SELECT AVG(t.cost_of_1_training) FROM Training t")
        double findAverageCost();

    @Query("SELECT AVG(TIMESTAMPDIFF(MINUTE, t.startTime, t.endTime)) FROM Training t")
    double findAverageDuration();

    @Query("SELECT t FROM Training t WHERE t.cost_of_1_training = (SELECT MAX(t2.cost_of_1_training) FROM Training t2)")
    Training findTrainingWithMaxCost();

    @Query("SELECT t FROM Training t WHERE t.cost_of_1_training = (SELECT MIN(t2.cost_of_1_training) FROM Training t2)")
    Training findTrainingWithMinCost();

    List<Training> findAll();

}
