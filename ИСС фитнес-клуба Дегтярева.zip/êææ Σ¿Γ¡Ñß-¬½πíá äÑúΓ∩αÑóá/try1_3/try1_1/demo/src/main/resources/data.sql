INSERT INTO trainings (name, start_time, end_time,cost_of_1_training) VALUES
('Кардио', '2024-11-26T10:00:00', '2024-11-26T11:00:00', 1000),
('Бокс', '2024-11-26T12:00:00', '2024-11-26T13:00:00', 2200),
('Круговая тренировка', '2024-11-26T14:00:00', '2024-11-26T15:00:00', 1500),
('Бокс lvl 2', '2024-11-27T12:00:00', '2024-11-27T13:00:00', 2500),
('Бокс', '2024-11-28T12:00:00', '2024-11-28T13:00:00', 3000),
('Кардио lvl 1', '2024-11-29T10:00:00', '2024-11-29T11:00:00', 1200),
('Кардио', '2024-11-30T10:00:00', '2024-11-30T11:00:00', 1100),
('Круговая тренировка lvl 2', '2024-12-01T14:00:00', '2024-12-01T15:00:00', 1600),
('Круговая тренировка', '2024-12-02T14:00:00', '2024-12-02T15:00:00', 1700),
('Йога', '2024-12-03T09:00:00', '2024-12-03T10:00:00', 2000),
('Пилатес', '2024-12-04T11:00:00', '2024-12-04T12:00:00', 1800),
('Силовая тренировка', '2024-12-05T15:00:00', '2024-12-05T16:00:00', 2200),
('Силовая тренировка', '2024-12-06T16:00:00', '2024-12-06T17:00:00', 2300),
('Фитнес', '2024-12-07T18:00:00', '2024-12-07T19:00:00', 1900),
('Фитнес', '2024-12-08T19:00:00', '2024-12-08T20:00:00', 2100);

-- Вставка данных о клиентах
INSERT INTO clients (full_name, birthdate, phone_number, login, password, coach)
VALUES
    ('Lewis Hamilton', '1985-01-07', '1234567890', 'lewis_hamilton', 'f1password123', 'Kakashi Hatake'),
    ('Max Verstappen', '1997-09-30', '0987654321', 'max_verstappen', 'f1password456', 'Killer Bee'),
    ('Monkey D. Luffy', '1997-05-05', '1122334455', 'monkey_d_luffy', 'animepassword789', 'Kakashi Hatake'),
    ('Naruto Uzumaki', '1999-10-10', '6677889900', 'naruto_uzumaki', 'animepassword101', 'Killer Bee');

-- Вставка данных о тренерах
INSERT INTO trainers (full_name, birthdate, phone_number, login, password, name, specialization)
VALUES
    ('Killer Bee', '1985-05-14', '5551234567', 'killerbee', 'trainerpass1', 'Killer Bee', 'Rapping & Taijutsu'),
    ('Kakashi Hatake', '1980-09-15', '5557654321', 'kakashi', 'trainerpass2', 'Kakashi Hatake', 'Ninjutsu & Strategy');

