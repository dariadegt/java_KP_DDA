-- Создание таблицы клиентов
CREATE TABLE clients (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    birthdate DATE NOT NULL,
    phone_number VARCHAR(50) NOT NULL,
    login VARCHAR(255) UNIQUE,
    password VARCHAR(255),
    coach VARCHAR(255)
);

-- Создание таблицы тренеров
CREATE TABLE trainers (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    birthdate DATE NOT NULL,
    phone_number VARCHAR(50) NOT NULL,
    login VARCHAR(255) UNIQUE,
    password VARCHAR(255),
    name VARCHAR(255) NOT NULL,
    specialization VARCHAR(255) NOT NULL
);

-- Создание таблицы тренировок
CREATE TABLE trainings (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    cost_of_1_training NUMERIC NOT NULL
);